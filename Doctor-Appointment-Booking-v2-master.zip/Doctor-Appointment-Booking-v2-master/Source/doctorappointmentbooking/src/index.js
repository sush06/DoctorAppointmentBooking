import React from 'react';
import ReactDOM from 'react-dom/client';
import NavBar from './main components/navbar';
import Footer from './main components/footer';
import Home from './Home';
import DoctorInsert from './app components/doctor/DoctorInsert';
import DoctorLogin from './app components/doctor/DoctorLogin';
import DoctorHome from './app components/doctor/DoctorHome';
import DoctorDetail from './app components/doctor/DoctorDetail';
import DoctorEdit from './app components/doctor/DoctorEdit';
import DoctorViewAppointments from './app components/doctor/DoctorViewAppointments';
import DoctorDelete from './app components/doctor/DoctorDelete';
import DoctorInvalidCredentials from './app components/doctor/DoctorInvalidCredentials';
import DoctorDetailsUpdated from './app components/doctor/DoctorDetailsUpdated';
import DoctorForgotPassword from './app components/doctor/DoctorForgotPassword';
import DoctorResetPassword from './app components/doctor/DoctorResetPassword';
import DoctorSelectHospital from './app components/doctor/DoctorSelectHospital';
import BookAppointment from './app components/patient/BookAppointment';
import BookAppointmentSuccessful from './app components/patient/BookAppointmentSuccessful';
import EditAppointment from './app components/patient/EditAppointment';
import EditAppointmentSuccessful from './app components/patient/EditAppointmentSuccessful';
import DeleteAppointment from './app components/patient/DeleteAppointment';
import PatientInsert from './app components/patient/PatientInsert';
import PatientViewAppointments from './app components/patient/PatientViewAppointments';
import PatientDetail from './app components/patient/PatientDetail';
import PatientLogin from './app components/patient/PatientLogin';
import PatientHome from './app components/patient/PatientHome';
import PatientEdit from './app components/patient/PatientEdit';
import PatientDelete from './app components/patient/PatientDelete';
import PatientInvalidCredentials from './app components/patient/PatientInvalidCredentials';
import PatientDetailsUpdated from './app components/patient/PatientDetailsUpdated';
import PatientForgotPassword from './app components/patient/PatientForgotPassword';
import PatientResetPassword from './app components/patient/PatientResetPassword';
import LoginPage from './LoginPage';
import RegistrationPage from './RegistrationPage';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <NavBar />
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path='/DoctorInsert' element={<DoctorInsert />}></Route>
        <Route path='/DoctorHome' element={<DoctorHome />}></Route>
        <Route path='/DoctorLogin' element={<DoctorLogin />}></Route>
        <Route path='/DoctorDetail' element={<DoctorDetail />} ></Route>
        <Route path='/DoctorEdit' element={<DoctorEdit />}></Route>
        <Route path='/DoctorViewAppointments' element={<DoctorViewAppointments />}></Route>
        <Route path='/DoctorDelete' element={<DoctorDelete />}></Route>
        <Route path='/DoctorInvalidCredentials' element={<DoctorInvalidCredentials />} ></Route>
        <Route path='/DoctorDetailsUpdated' element={<DoctorDetailsUpdated />}></Route>
        <Route path='/DoctorForgotPassword' element={<DoctorForgotPassword />}></Route>
        <Route path='/DoctorResetPassword' element={<DoctorResetPassword />}></Route>
        <Route path='/DoctorSelectHospital' element={<DoctorSelectHospital />}></Route>
        <Route path='/PatientLogin' element={<PatientLogin />}></Route>
        <Route path='/PatientHome' element={<PatientHome />}></Route>
        <Route path='/BookAppointment' element={<BookAppointment />}></Route>
        <Route path='/BookAppointmentSuccessful' element={<BookAppointmentSuccessful />}></Route>
        <Route path='/EditAppointment' element={<EditAppointment />}></Route>
        <Route path='/EditAppointmentSuccessful' element={<EditAppointmentSuccessful />} ></Route>
        <Route path='/DeleteAppointment' element={<DeleteAppointment />}></Route>
        <Route path='/PatientViewAppointments' element={<PatientViewAppointments />}></Route>
        <Route path='/PatientDetail' element={<PatientDetail />}></Route>
        <Route path='/PatientInsert' element={<PatientInsert />}></Route>
        <Route path='/PatientEdit' element={<PatientEdit />}></Route>
        <Route path='/PatientDelete' element={<PatientDelete />}></Route>
        <Route path='/PatientInvalidCredentials' element={<PatientInvalidCredentials />}></Route>
        <Route path='/PatientDetailsUpdated' element={<PatientDetailsUpdated />}></Route>
        <Route path='/PatientForgotPassword' element={<PatientForgotPassword />}></Route>
        <Route path='/PatientResetPassword' element={<PatientResetPassword />}></Route>
        <Route path='/LoginPage' element={<LoginPage />}></Route>
        <Route path='/RegistrationPage' element={<RegistrationPage />}></Route>
      </Routes>
    </BrowserRouter>
    <Footer />
  </React.StrictMode>
);
import React from "react";
import DataService from "../../DataService";
import Doc from '../../images/appUpdate.jpg';
import login from '../../images/appointmentUpdate.png';
import '../../css/appointmentupdate.css';

class EditAppointment extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            PatientEmail: "",
            DoctorName: "",
            Day: "",
            Time: "",
            AppointmentMode: "",
            MedicalReports: ""
        }
        this.componentDidMount = () => {
            this.getFormData = () => {
                const img = new FormData();
                img.append("PatientEmail", this.state.PatientEmail);
                img.append("DoctorName", this.state.DoctorName);
                img.append("Day", this.state.Day);
                img.append("Time", this.state.Time);
                img.append("AppointmentMode", this.state.AppointmentMode);
                img.append("MedicalReports", this.state.MedicalReports);
                return img;
            }
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.getFormData(),
                    success: (response) => {
                        this.setState({ UpdateAppointment: response });
                        //alert("Form Submitted......");
                        //window.location.href = "/DoctorHome";
                    },
                    error: function (error) {
                        console.log(error);
                    }
                }
                e.preventDefault();
                DataService.UpdateAppointment(requestObject);
                alert("Details Updated!");
                window.location.href = "/EditAppointmentSuccessful";
            }
        }
    }
    render() {
        return (
            <div className="auloginpageBackground" style={{ padding: "160px", }}>

                <center>
                    {/* main div */}
                    <div className="aumaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "800px", }} className="auChildDiv">
                            <br />
                            <img src={Doc} alt="doctor" className="audocimg" />
                            <h1 style={{ color: "rgb(46, 75, 87)" }}>Edit Your Appointment</h1><br />
                            <form onSubmit={this.onSubmit}>

                                <lable className="aupasswordstyle"><i class="fa-solid fa-bed"></i> Patient Email</lable>
                                <input className="aufeildwidth" required type="email" name="PatientEmail" id="PatientEmail" value={this.state.PatientEmail} onChange={(e) => this.setState({ PatientEmail: e.target.value })} /><br /><br />

                                <lable className="aupasswordstyle"><i class="fa-solid fa-user-doctor"></i> Doctor Name</lable>
                                <input className="aufeildwidth" required type="text" name="DoctorName" id="DoctorName" value={this.state.DoctorName} onChange={(e) => this.setState({ DoctorName: e.target.value })} /><br /><br />

                                <label htmlFor="Dob" className="audatestyle"><i class="fa-solid fa-calendar-days"></i> Day</label>
                                <input className="aufeildwidth" required type="text" name="Day" id="Day" value={this.state.Day} onChange={(e) => this.setState({ Day: e.target.value })} /><br /><br />


                                <label htmlFor="Dob" className="audatestyle"><i class="fa-solid fa-calendar-days"></i> Date</label>
                                <input className="aufeildwidth" required type="date" /><br /><br />


                                <lable className="auemailstyle" htmlfor="password"><i class="fa-solid fa-clock"></i> Time</lable>
                                <input className="aufeildwidth" required type="time" name="Time" id="Time" value={this.state.Time} onChange={(e) => this.setState({ Time: e.target.value })} /><br /><br />

                                <label htmlFor="Dob" className="aureportstyle"><i class="fa-solid fa-calendar-days"></i> Reports</label>
                                <input className="aufeildwidth" required type="file" name="MedicalReports" id="MedicalReports" onChange={(e) => this.setState({ MedicalReports: e.target.files[0] })} /><br /><br />

                                <label htmlFor="Dob" className="auamtstyle"><i class="fa-solid fa-calendar-days"></i> Mode</label>
                                <input className="aufeildwidth" required type="text" name="AppointmentMode" id="AppointmentMode" value={this.state.AppointmentMode} onChange={(e) => this.setState({ AppointmentMode: e.target.value })} /><br /><br />


                                <button type="button" onClick={this.onSubmit} className="auloginstyle">Update my Appointment!</button>

                                <br />
                                <a href="/PatientHome"><p>Back to Home</p></a>


                            </form>
                        </div>
                        {/* image div*/}
                        <div className="auChildDiv">
                            <center>
                                <br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
                                <img src={login} alt="doctor login pictor" className="auimgwidth" />
                            </center>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default EditAppointment;
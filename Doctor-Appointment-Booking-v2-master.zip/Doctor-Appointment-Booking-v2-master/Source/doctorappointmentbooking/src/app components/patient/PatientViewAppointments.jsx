import React from "react";
import DataService from "../../DataService";
import '../../css/tables.css';
class PatientViewAppointments extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            patientEmail: "",
            appointmentId: "",
            doctorName: "",
            day: "",
            time: "",
            appointmentMode: ""
        }
        this.componentDidMount = () => {
            var requestObject = {
                data: localStorage.getItem("PatientEmail"),
                success: (response) => {
                    this.setState({ appointmentId: response.appointmentId, patientEmail: response.patientEmail, doctorName: response.doctorName, day: response.day, time: response.time, appointmentMode: response.appointmentMode });
                    console.log(response);
                },
                error: function (error) {
                    console.log(error)
                }
            }
            DataService.ViewAppointment(requestObject);
        }
    }

    render() {
        return (
            <div>
                <div>
                    <br />
                    <center>


                        <table>
                            <tr>
                                <th>Appointment ID</th>
                                <th>Patient Email</th>
                                <th>Doctor Name</th>
                                <th>Day</th>
                                <th>Appointment Mode</th>
                                <th>Time</th>
                            </tr><tr>
                                <td>{this.state.appointmentId}</td>
                                <td>{this.state.patientEmail}</td>
                                <td>{this.state.doctorName}</td>
                                <td>{this.state.day}</td>
                                <td>{this.state.appointmentMode}</td>
                                <td>{this.state.time.hours + ":" + this.state.time.minutes}</td>
                                {/*<td>{this.state.time}</td>*/}
                            </tr>
                        </table>
                        <br />
                        <a href="/PatientHome"><button type="button" style={{ borderRadius: 3, color: 'rgb(38, 37, 37)', backgroundColor: 'rgb(247, 191, 191)', border: '1px solid rgb(251, 207, 207)', textAlign: 'center', padding: 5 }}>Back</button></a>
                    </center>
                </div>
            </div>
        );
    }
}

export default PatientViewAppointments;
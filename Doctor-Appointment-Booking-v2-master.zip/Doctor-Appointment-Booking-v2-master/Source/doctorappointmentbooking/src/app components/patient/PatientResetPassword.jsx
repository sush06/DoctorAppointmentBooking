import React from "react";
import DataService from "../../DataService";
import Gif from '../../images/forgotpassword.gif';
import "../../css/patientRegistration.css";

class PatientResetPassword extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            PatientEmail: "",
            PatientPassword: ""
        }
        this.componentDidMount = () => {
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.state,
                    success: (response) => {
                        this.setState({ PatientResetPassword: response });
                        console.log(response);
                        //window.location.href = "/PatientHome";
                    },
                    error: function (error) {
                        console.log(error);
                        //window.location.href = "/PatientInvalidCredentials";
                    }
                }
                e.preventDefault();
                //localStorage.setItem("PatientEmail", this.state.PatientEmail);
                DataService.PatientResetPassword(requestObject);
                // if (window.confirm('If you click "ok" you would be redirected . Cancel will load this website ')) {
                //     window.location.href = '/PatientLogin';
                // };
                alert("Password Changed Successfully! To continue click on Patient Login...");
                //window.location.href = "/PatientLogin";

            }
        }
    }
    render() {
        return (
            <div>
                <center>
                    <img src={Gif} width={"40%"} height={"350px"} /><br />
                    <br />
                    <h3>Enter your email along with the new password to reset your password</h3>
                    <form onSubmit={this.onSubmit}>
                        <label htmlFor="PatientEmail" className="premailstyle">Email</label>
                        <input id="PatientEmail" name="PatientEmail" type="text" value={this.state.PatientEmail} onChange={(e) => this.setState({ PatientEmail: e.target.value })} required placeholder="Email" className="loginClass" /><br /><br />
                        <label htmlFor="PatientPassword" className="premailstyle">New Password</label>
                        <input id="PatientPassword" name="PatientPassword" type="password" value={this.state.PatientPassword} onChange={(e) => this.setState({ PatientPassword: e.target.value })} required placeholder="Password" className="loginClass" /><br /><br />
                        <div style={{ paddingLeft: 50 }}>
                            <button type="submit" onClick={this.onSubmit} style={{ borderRadius: 3, color: 'rgb(0, 0, 0)', backgroundColor: 'dodgerblue', border: '1px solid dodgerblue', textAlign: 'center', padding: 5 }}>Submit</button>
                        </div>
                    </form><br /><br />
                </center>
            </div>
        );
    }
}
export default PatientResetPassword;
import React from "react";
import DataService from "../../DataService";
import login from '../../images/patientlogin.jpg';
import '../../css/patientupdate.css';
import Doc from '../../images/pat.png'

class PatientEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            PatientEmail: "",
            PatientPassword: "",
            PatientName: "",
            Disease: "",
            Dob: "",
            PatientImage: ""
        }
        this.componentDidMount = () => {
            this.getFormData = () => {
                const img = new FormData();
                img.append("PatientEmail", this.state.PatientEmail);
                img.append("PatientPassword", this.state.PatientPassword);
                img.append("PatientName", this.state.PatientName);
                img.append("Disease", this.state.Disease);
                img.append("Experience", this.state.Experience);
                img.append("Dob", this.state.Dob);
                img.append("PatientImage", this.state.PatientImage);
                return img;
            }
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.getFormData(),
                    success: (response) => {
                        this.setState({ UpdatePatient: response });
                        //alert("Form Submitted......");
                        //window.location.href = "/DoctorHome";
                    },
                    error: function (error) {
                        console.log(error);
                    }
                }
                e.preventDefault();
                DataService.UpdatePatient(requestObject);
                alert("Form Submitted!");
                window.location.href = "/PatientHome";
            }
        }
    }
    render() {
        return (
            <div className="puloginpageBackground" style={{ padding: "160px", }}>

                <center>
                    {/* main div */}
                    <div className="pumaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "700px", }} className="puChildDiv">
                            <br />
                            <img src={Doc} alt="doctor" className="pudocimg" />
                            <h1 style={{ color: "rgb(83, 154, 234)" }}>Patient Profile Update</h1><br />
                            <form onSubmit={this.onSubmit}>

                                <label className="puemailstyle">Name</label>
                                <input className="prfeildwidth" required type="text" name="PatientName" id="PatientName" value={this.state.PatientName} onChange={(e) => this.setState({ PatientName: e.target.value })} /><br /><br /><br />

                                <label htmlFor="Dob" className="pudobstyle">DOB</label>
                                <input className="pufeildwidth" required type="date" name="Dob" id="Dob" value={this.state.Dob} onChange={(e) => this.setState({ Dob: e.target.value })} /><br /><br />

                                <label className="puemailstyle" htmlfor="PatientEmail"><i class="fa-solid fa-user-doctor-hair-long" style={{ color: "black" }}></i>Email</label>
                                <input className="pufeildwidth" type="email" name="PatientEmail" id="PatientEmail" value={this.state.PatientEmail} onChange={(e) => this.setState({ PatientEmail: e.target.value })} /><br /><br />

                                <label className="pupasswordstyle" htmlfor="PatientPassword">Password</label>
                                <input className="pufeildwidth" type="password" name="PatientPassword" id="PatientPassword" value={this.state.PatientPassword} onChange={(e) => this.setState({ PatientPassword: e.target.value })} /><br /><br />


                                <label className="pudesstyle" htmlFor="Disease">Disease</label>
                                <input className="pufeildwidth" required type="text" name="Disease" id="Disease" value={this.state.Disease} onChange={(e) => this.setState({ Disease: e.target.value })} /><br /><br />


                                <label htmlFor="PatientImage" className="pupicstyle">Profile Picture</label>
                                <input className="pupicfeildwidth" required type="file" name="PatientImage" id="PatientImage" onChange={(e) => this.setState({ PatientImage: e.target.files[0] })} /><br /><br />


                                <button type="button" onClick={this.onSubmit} className="puloginstyle">Update my details!</button>

                            </form>
                            <br />
                            <a href="/PatientHome">
                                <p>Back to Home</p>
                            </a>
                        </div>
                        {/* image div*/}
                        <div className="puChildDiv">
                            <center>
                                <br /><br /><br /><br /><br /><br /><br /><br />
                                <img src={login} alt="doctor login pictor" className="puimgwidth" />
                            </center>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default PatientEdit;
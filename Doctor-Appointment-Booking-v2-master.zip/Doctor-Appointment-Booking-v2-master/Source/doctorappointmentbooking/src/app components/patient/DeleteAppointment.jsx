import React from "react";
import Del from '../../images/profileDelete.gif';

class DeleteAppointment extends React.Component {
    render() {
        return (
            <div>
                <center><br /><br />
                    <h1>Appointment Deleted!</h1>
                    <img src={Del} width={"600px"} height={"500px"} />

                    <a href="/BookAppointment">
                        <p><b>Click here to schedule a new Appointment!</b></p>
                    </a>
                    <a href="/PatientHome">
                        <p><b>Home</b></p>
                    </a>
                </center>
            </div>
        );
    }
}

export default DeleteAppointment;
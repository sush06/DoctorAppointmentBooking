import React from "react";
import DataService from "../../DataService";
import book from "../../images/bookappointment.gif";

class BookAppointmentSuccessful extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            PatientEmail: ""
        }
        this.componentDidMount = () => {
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.state,
                    success: (response) => {
                        this.setState({ BookAppointmentSuccessful: response });
                        console.log(response);
                        //window.location.href = "/PatientHome";
                    },
                    error: function (error) {
                        console.log(error);
                        //window.location.href = "/PatientInvalidCredentials";
                    }
                }
                e.preventDefault();
                //localStorage.setItem("PatientEmail", this.state.PatientEmail);
                DataService.BookAppointmentSuccessful(requestObject);
                alert("An Email has been sent to you! Please check your email!");
                // if (window.confirm('If you click "ok" you would be redirected . Cancel will load this website ')) {
                //     window.location.href = '/PatientLogin';
                // };
                //alert("Password Changed Successfully! To continue click on Patient Login...");
                //window.location.href = "/PatientLogin";

            }
        }
    }
    render() {
        return (
            <div>
                <center>
                    <h1>Your Appointment has been Scheduled!</h1>
                    <img src={book} width={"70%"} height={"550px"} />
                    <h3>Send me an acknowledgement</h3>
                    <form onSubmit={this.onSubmit}>
                        <input type="email" name="PatientEmail" id="PatientEmail" value={this.state.PatientEmail} onChange={(e) => this.setState({ PatientEmail: e.target.value })} ></input>
                        <button type="submit" onClick={this.onSubmit}>Mail Me!</button>
                    </form>

                    <a href="/PatientHome"><button type="button" style={{ borderRadius: 3, color: 'rgb(38, 37, 37)', backgroundColor: 'rgb(247, 191, 191)', border: '1px solid rgb(251, 207, 207)', textAlign: 'center', padding: 5 }}>Go Back</button></a>
                    <br />
                </center>
                <br />
            </div>
        );
    }
}

export default BookAppointmentSuccessful;
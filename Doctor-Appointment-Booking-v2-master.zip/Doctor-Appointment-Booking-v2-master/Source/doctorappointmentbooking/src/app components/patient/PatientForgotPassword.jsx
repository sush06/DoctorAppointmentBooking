import React from "react";
import DataService from "../../DataService";
import Gif from '../../images/forgotpassword.gif';
import "../../css/patientRegistration.css";

class PatientForgotPassword extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            PatientEmail: "",
        }
        this.componentDidMount = () => {
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.state,
                    success: (response) => {
                        this.setState({ PatientForgotPassword: response });
                        console.log(response);
                        alert("Mail sent. Please check your email!");
                        //window.location.href = "/PatientHome";
                    },
                    error: function (error) {
                        console.log(error);
                        window.location.href = "/PatientInvalidCredentials";
                    }
                }
                e.preventDefault();
                DataService.PatientForgotPassword(requestObject);
                //alert("Log In Successfull!");

            }
        }
    }
    render() {
        return (
            <div>
                <center>
                    <br />
                    <br />
                    <img src={Gif} width={"40%"} height={"350px"} /><br />
                    <br />
                    <h3>Enter your email ID below to reset your password!</h3>
                    <form onSubmit={this.onSubmit}>
                        <label htmlFor="PatientEmail" className="premailstyle">Email</label>
                        <input id="PatientEmail" name="PatientEmail" type="text" value={this.state.PatientEmail} onChange={(e) => this.setState({ PatientEmail: e.target.value })} required placeholder="Email" className="loginClass" /><br /><br />
                        <div style={{ paddingLeft: 50 }}>
                            <button type="submit" style={{ borderRadius: 3, color: 'rgb(0, 0, 0)', backgroundColor: 'dodgerblue', border: '1px solid dodgerblue', textAlign: 'center', padding: 5 }}>Submit</button>
                        </div>
                    </form><br /><br />
                </center>

            </div>
        );
    }
}

export default PatientForgotPassword;
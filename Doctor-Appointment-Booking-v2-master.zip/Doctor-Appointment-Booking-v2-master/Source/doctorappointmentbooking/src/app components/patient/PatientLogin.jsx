import React from "react";
import DataService from "../../DataService";
import login from '../../images/patientlogin.jpg';
import Pat from '../../images/pat.png';
import '../../css/patientlogin.css';

class PatientLogin extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            PatientEmail: "",
            PatientPassword: ""
        }
        this.componentDidMount = () => {
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.state,
                    success: (response) => {
                        this.setState({ LoginPatient: response });
                        console.log(response);
                        localStorage.setItem("PatientEmail", this.state.PatientEmail);
                        window.location.href = "/PatientHome";
                    },
                    error: function (error) {
                        console.log(error);
                        window.location.href = "/PatientInvalidCredentials";
                    }
                }
                e.preventDefault();
                localStorage.setItem("PatientEmail", this.state.PatientEmail);
                DataService.LoginPatient(requestObject);
                //alert("Log In Successfull!");

            }
        }
    }
    render() {
        return (
            <div className="loginpageBackground" style={{ padding: "160px", }}>

                <center>
                    {/* main div */}
                    <div className="ptmaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "500px", borderRadius: "5px" }} className="ChildDiv">
                            <br />
                            <img src={Pat} alt="doctor" className="docimg" />
                            <h1 style={{ color: "rgb(83, 154, 234)" }}>Patient Login</h1><br />
                            <form onSubmit={this.onSubmit}>

                                <label className="emailstyle" htmlfor="PatientEmail"><i class="fa-solid fa-bed"></i> Email</label>
                                <input type="email" className="feildwidth" id="PatientEmail" name="PatientEmail" value={this.state.PatientEmail} onChange={(e) => this.setState({ PatientEmail: e.target.value })} /><br /><br />
                                <label className="passwordstyle" htmlfor="PatientPassword"><i class="fa-solid fa-lock"></i> Password</label>
                                <input type="Password" className="feildwidth" id="PatientPassword" name="PatientPassword" value={this.state.PatientPassword} onChange={(e) => this.setState({ PatientPassword: e.target.value })} /><br /><br />
                                <h6>Forgot your Password?</h6><a href="/PatientForgotPassword">Click here!</a>
                                <br />
                                <br />
                                <button type="submit" onClick={this.onSubmit} className="loginstyle">Login</button>
                                <a href="/PatientInsert">
                                    <p style={{ color: "rgb(83, 154, 234)" }}>Don't have an Account ? Click here to Register!</p></a>
                            </form>
                        </div>
                        {/* image div*/}
                        <div className="ChildDiv"><br /><br />
                            <center><img src={login} alt="doctor login pictor" className="imgwidth" /></center>
                        </div>
                    </div >
                </center >
            </div >
        );
    }
}

export default PatientLogin;
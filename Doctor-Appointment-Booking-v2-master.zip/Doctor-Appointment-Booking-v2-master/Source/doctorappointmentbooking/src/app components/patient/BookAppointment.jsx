import React from "react";
import DataService from "../../DataService";
import login from '../../images/appointmentBooking.jpg';
import Doc from '../../images/calender.jpeg';
import '../../css/appointmentBooking.css';
import Doc1 from '../../images/doctorProfileimg.jpg'
import Doc2 from '../../images/doc2.jpg';
import Doc3 from '../../images/doc3.jpg';
import Doc5 from '../../images/doc5.jpg';


class BookAppointment extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            PatientEmail: "",
            DoctorName: "",
            Day: "",
            Time: "",
            MedicalReports: "",
            AppointmentMode: "",
            doctor: []
        }
        this.componentDidMount = () => {
            var object = {
                success: (response) => {
                    console.log(response);
                    this.setState({ doctor: response });
                },
                error: function (error) {
                    console.log(error);
                }
            }
            DataService.ListDoctors(object);

            this.getFormData = () => {
                const img = new FormData();
                img.append("PatientEmail", this.state.PatientEmail);
                img.append("DoctorName", this.state.DoctorName);
                img.append("Day", this.state.Day);
                img.append("Time", this.state.Time);
                img.append("MedicalReports", this.state.MedicalReports);
                img.append("AppointmentMode", this.state.AppointmentMode);
                return img;
            }
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.getFormData(),
                    success: (response) => {
                        this.setState({ BookAppointment: response });
                    },
                    error: function (error) {
                        console.log(error)
                    }
                }
                e.preventDefault();
                DataService.BookAppointment(requestObject);
                alert("Appointment Booked!");
                window.location.href = "/BookAppointmentSuccessful";
            }
        }
    }
    render() {
        return (
            <div className="abloginpageBackground" style={{ paddingLeft: "200px", paddingBottom: "25px" }}>
                {
                    this.state.doctor.map((doctor) =>
                        <div className="cardChildDiv" ><br /><br /><br />
                            <div style={{ padding: "0px", borderRadius: "10px", border: "2px solid lightgry", width: "250px", height: "650px", padding: "10px", boxShadow: "5px 5px 10px rgb(204, 203, 203) ", background: "white" }} className="cardChildDiv">
                                <img src={"data:image/png;base64," + doctor.doctorImage} width={"230px"} height={"200px"} /><br /><br />
                                <div className="infocss">
                                    <p><b>Doctor Name:</b> {doctor.doctorName} </p>
                                    <p><b>Specialization:</b> {doctor.specialization}</p>
                                    <p><b>Experience:</b> {doctor.experience}</p>
                                    <p><b>Hospital:</b> {doctor.hospital}</p>
                                    <p><b>Day: </b>{doctor.day}</p>
                                    <p><b>Email:</b> {doctor.doctorEmail} </p>
                                    {doctor.startTime != null && <p><b>Timings: </b> {doctor.startTime.hours + ":" + doctor.startTime.minutes} to {doctor.endTime.hours + ":" + doctor.endTime.minutes} </p>}
                                </div>
                            </div>
                            <div style={{ width: "30px", height: "390px" }} className="cardChildDiv"></div>
                        </div>
                    )
                }
                <center>
                    <br />
                    <br />
                    {/* main div */}
                    <div className="abmaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "730px", }} className="abChildDiv">
                            <br /><br />
                            <img src={Doc} alt="doctor" className="abdocimg" />
                            <h1 style={{ color: "black" }}>Schedule your Appointment</h1><br />
                            <form onSubmit={this.onSubmit}>

                                <label className="abpasswordstyle"><i class="fa-solid fa-bed"></i> Patient Email</label>
                                <input className="abfeildwidth" required type="email" id="PatientEmail" name="PatientEmail" value={this.state.PatientEmail} onChange={(e) => this.setState({ PatientEmail: e.target.value })} /><br /><br />

                                <label className="abpasswordstyle"><i class="fa-solid fa-user-doctor"></i> Doctor Name</label>
                                <input className="abfeildwidth" required type="text" id="DoctorName" name="DoctorName" value={this.state.DoctorName} onChange={(e) => this.setState({ DoctorName: e.target.value })} /><br /><br />

                                <label htmlFor="Day" className="abdatestyle"><i class="fa-solid fa-calendar-days"></i> Day</label>
                                <input className="abfeildwidth" required type="text" id="Day" name="Day" value={this.state.Day} onChange={(e) => this.setState({ Day: e.target.value })} /><br /><br />


                                <label className="abemailstyle" htmlfor="password"><i class="fa-solid fa-clock"></i> Time</label>
                                <input className="abfeildwidth" required type="time" id="Time" name="Time" value={this.state.Time} onChange={(e) => this.setState({ Time: e.target.value })} /><br /><br />

                                <label htmlFor="Dob" className="abreportstyle"><i class="fa-solid fa-calendar-days"></i>Reports</label>
                                <input className="abfeildwidth" required type="file" name="MedicalReports" id="MedicalReports" onChange={(e) => this.setState({ MedicalReports: e.target.files[0] })} /><br /><br />

                                <label htmlFor="AppointmentMode" className="abdatestyle"><i class="fa-solid fa-calendar-days"></i>Mode</label>
                                <input className="abfeildwidth" required type="text" id="AppointmentMode" name="AppointmentMode" value={this.state.AppointmentMode} onChange={(e) => this.setState({ AppointmentMode: e.target.value })} /><br /><br />
                                <button type="submit" onClick={this.onSubmit} className="abloginstyle">Book</button>
                                <br />
                                <br />
                            </form>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default BookAppointment;
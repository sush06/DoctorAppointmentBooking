import React from "react";
import DataService from "../../DataService";
import '../../css/doctorProfile.css';
import login from '../../images/DoctorProfile.jpg'

class PatientDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            patientEmail: "",
            patientName: "",
            dob: "",
            disease: "",
            patientImage: ""
        }
        this.componentDidMount = () => {
            var requestObject = {
                data: localStorage.getItem("PatientEmail"),
                success: (response) => {
                    this.setState({ patientEmail: response.patientEmail, patientName: response.patientName, dob: response.dob, disease: response.disease, patientImage: response.patientImage });
                    console.log(response);
                },
                error: function (error) {
                    console.log(error)
                }
            }
            DataService.ViewPatient(requestObject);
        }
    }
    render() {
        return (
            <div className="dploginpageBackground" style={{ padding: "100px", }}>

                <center>

                    {/* main div */}
                    <div className="dpmaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "600px", }} className="dpChildDiv">
                            <br />
                            <img src={"data:image/png;base64," + this.state.patientImage} alt="doctor" className="dpdocimg" />
                            <h1 style={{ color: "black" }}>Doctor Profile</h1><br />
                            <div>
                                <p><b>Name:</b> {this.state.patientName}</p>
                                <p><b>DOB:</b> {this.state.dob}</p>
                                <p><b>Email:</b> {this.state.patientEmail}</p>
                                <p><b>Disease:</b> {this.state.disease}</p><br />
                                {/*{this.state.startTime != null && <p><b>Timings: </b> {this.state.startTime.hours + ":" + this.state.startTime.minutes} to {this.state.endTime.hours + ":" + this.state.endTime.minutes} </p>}<br /><br />*/}
                                <a href="/PatientHome"><p style={{ color: "blue" }}>Back to Home</p></a>
                            </div><br /><br />

                        </div>
                        {/* image div*/}
                        <div className="dpChildDiv">
                            <center>
                                <br /><br />
                                <img src={login} alt="doctor login pictor" className="dpimgwidth" />
                            </center>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default PatientDetail;
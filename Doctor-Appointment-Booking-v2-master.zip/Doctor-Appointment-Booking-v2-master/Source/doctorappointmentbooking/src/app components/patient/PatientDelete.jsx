import React from "react";
import Del from '../../images/profileDelete.gif';
class PatientDelete extends React.Component {
    render() {
        return (
            <div>
                <center><br /><br />
                    <h1>Account Deleted!</h1>
                    <img src={Del} width={"600px"} height={"500px"} />

                    <a href="/PatientInsert">
                        <p><b>Click here to Register!</b></p>
                    </a>
                </center>
            </div>
        );
    }
}

export default PatientDelete;
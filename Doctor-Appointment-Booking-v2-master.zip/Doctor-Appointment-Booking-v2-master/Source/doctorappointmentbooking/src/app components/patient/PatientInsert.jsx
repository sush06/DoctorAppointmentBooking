import React from "react";
import DataService from "../../DataService";
import '../../css/patientRegistration.css';
import Doc from '../../images/pat.png';
import login from '../../images/patientlogin.jpg';

class PatientInsert extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            PatientEmail: "",
            PatientName: "",
            PatientPassword: "",
            Dob: "",
            Disease: "",
            PatientImage: ""
        }
        this.componentDidMount = () => {
            this.getFormData = () => {
                const img = new FormData();
                img.append("PatientEmail", this.state.PatientEmail);
                img.append("PatientName", this.state.PatientName);
                img.append("PatientPassword", this.state.PatientPassword);
                img.append("Dob", this.state.Dob);
                img.append("Disease", this.state.Disease);
                img.append("PatientImage", this.state.PatientImage);
                return img;
            }
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.getFormData(),
                    success: (response) => {
                        this.setState({ InsertPatient: response });
                    },
                    error: function (error) {
                        console.log(error)
                    }
                }
                e.preventDefault();
                DataService.InsertPatient(requestObject);
                alert("Registration Successfull!");
                window.location.href = "/PatientLogin";
            }
        }
    }
    render() {
        return (
            <div className="prloginpageBackground" style={{ padding: "160px", }}>

                <center>
                    {/* main div */}
                    <div className="prmaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "750px", }} className="prChildDiv">
                            <br /><br />
                            <img src={Doc} alt="doctor" className="prdocimg" />
                            <h1 style={{ color: "rgb(83, 154, 234)" }}>Patient Registration</h1><br />
                            <form onSubmit={this.onSubmit}>

                                <label className="premailstyle"><i className="fa-solid fa-user"></i> Name</label>
                                <input className="prfeildwidth" id="PatientName" name="PatientName" type="text" value={this.state.PatientName} onChange={(e) => this.setState({ PatientName: e.target.value })} required /><br /><br />

                                <label htmlFor="Dob" className="prdobstyle"><i className="fa-solid fa-calendar-days"></i> DOB</label>
                                <input className="prfeildwidth" name="Dob" id="Dob" type="date" value={this.state.Dob} onChange={(e) => this.setState({ Dob: e.target.value })} required /><br /><br />

                                <label className="premailstyle" htmlfor="PatientEmail"><i className="fa-solid fa-envelope"></i> Email</label>
                                <input className="prfeildwidth" type="email" id="PatientEmail" name="PatientEmail" value={this.state.PatientEmail} onChange={(e) => this.setState({ PatientEmail: e.target.value })} /><br /><br />

                                <label className="prpasswordstyle" htmlfor="PatientPassword"><i class="fa-solid fa-lock"></i> Password</label>
                                <input className="prfeildwidth" name="PatientPassword" id="PatientPassword" type="password" value={this.state.PatientPassword} onChange={(e) => this.setState({ PatientPassword: e.target.value })} /><br /><br />


                                <label className="prdesstyle" htmlFor="Disease"><i className="fa-solid fa-user"></i>Illness</label>
                                <input className="prfeildwidth" required name="Disease" id="Disease" type="text" value={this.state.Disease} onChange={(e) => this.setState({ Disease: e.target.value })} /><br /><br />


                                <label htmlFor="PatientImage" className="prpicstyle"><i className="fa-solid fa-image"></i> Profile Picture</label>
                                <input className="prpicfeildwidth" required type="file" name="PatientImage" id="PatientImage" onChange={(e) => this.setState({ PatientImage: e.target.files[0] })} /><br /><br /><br />

                                <button type="button" onClick={this.onSubmit} className="prloginstyle">Register</button><br />
                                <br />
                                <a href="/PatientLogin" style={{ color: "rgb(83, 154, 234)" }}>
                                    <p style={{ color: "rgb(83, 154, 234)" }}>Already have an account? <br />Click here to login!</p>
                                </a>


                            </form>
                        </div>
                        {/* image div*/}
                        <div className="prChildDiv">
                            <center>
                                <br /><br /><br /><br /><br /><br /><br /><br />
                                <img src={login} alt="doctor login pictor" className="primgwidth" />
                            </center>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default PatientInsert;
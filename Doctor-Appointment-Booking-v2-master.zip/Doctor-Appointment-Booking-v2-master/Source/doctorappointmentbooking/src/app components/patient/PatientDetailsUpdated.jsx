import React from "react";
import update from '../../images/update.gif';

class PatientDetailsUpdated extends React.Component {
    render() {
        return (
            <div>
                <br />
                <center>
                    <h1>Details Updated Successfully!!!</h1>
                    <img src={update} width={"70%"} height={"450px"} /><br />
                    <a href="/PatientHome"><button type="button" style={{ borderRadius: 3, color: 'rgb(38, 37, 37)', backgroundColor: 'rgb(247, 191, 191)', border: '1px solid rgb(251, 207, 207)', textAlign: 'center', padding: 5 }}>Go Back</button></a>
                    <br />
                </center>
            </div>

        );
    }
}

export default PatientDetailsUpdated;
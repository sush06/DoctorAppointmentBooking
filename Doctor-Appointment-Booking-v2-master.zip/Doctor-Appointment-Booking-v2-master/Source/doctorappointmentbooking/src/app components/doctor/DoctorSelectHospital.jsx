import React from "react";
import DataService from "../../DataService";

class DoctorSelectHospital extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            listHospitals: []
        }
        this.componentDidMount = () => {
            var requestObject = {
                success: (response) => {
                    this.setState({ listHospitals: response });
                    console.log(response);
                },
                error: function (error) {
                    console.log(error);
                }
            }
            DataService.ListHospitals(requestObject);
        }
        this.onSubmit = (e) => {
            e.preventDefault();
            var tmp = localStorage.getItem("DoctorEmail");
            var requestObject = {
                data: { DoctorEmail: tmp },
                success: (response) => {
                    this.setState({ DoctorHospitalInsert: response });
                    console.log(response);
                },
                error: function (error) {
                    console.log(error);
                }
            }
            DataService.DoctorHospitalInsert(requestObject);
            alert("Form Submitted!");
            window.location.href = "/DoctorHome";
        }
    }

    // onSubmit = (e) => {
    //     e.preventDefault();
    //     var tmp = localStorage.getItem("DoctorEmail");
    //     var requestObject = {
    //         success: (response) => {
    //             console.log(response);
    //             //localStorage.removeItem("DoctorEmail");
    //             //window.location.href = "/DoctorDelete";
    //         },
    //         error: function (error) {
    //             console.log(error);
    //             window.location.href = "/DoctorInvalidCredentials";
    //         }
    //     }
    //     DataService.ListHospitals(requestObject);
    //     //alert("Delete Successful!");
    // }
    render() {
        return (
            <div>
                <h1>Hi Doctor!</h1>
                <h2>Please select your Hospital.</h2>
                <form onSubmit={this.onSubmit}>
                    <label>Select one Hospital from the given list</label>
                    <select>
                        <option>--select--</option>
                        {
                            this.state.listHospitals.map(
                                hospital => <><option value={this.state.listHospitals}>{hospital.hospitalName}</option></>
                            )
                        }
                    </select>
                    <button type="submit" onClick={this.onSubmit} >Submit</button>
                </form>
            </div>
        );
    }
}

export default DoctorSelectHospital;
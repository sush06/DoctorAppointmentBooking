import React from "react";
import DataService from "../../DataService";
import '../../css/doctorProfile.css';
import Doc from '../../images/doctorProfileimg.jpg';
import login from '../../images/DoctorProfile.jpg';

class DoctorDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            doctorEmail: "",
            doctorName: "",
            specialization: "",
            experience: "",
            dob: "",
            hospital: "",
            day: "",
            startTime: "",
            endTime: "",
            doctorImage: ""
        }
        this.componentDidMount = () => {
            var requestObject = {
                data: localStorage.getItem("DoctorEmail"),
                success: (response) => {
                    this.setState({ doctorEmail: response.doctorEmail, doctorName: response.doctorName, specialization: response.specialization, experience: response.experience, dob: response.dob, hospital: response.hospital, day: response.day, startTime: response.startTime, endTime: response.endTime, doctorImage: response.doctorImage });
                    console.log(response);
                },
                error: function (error) {
                    console.log(error)
                }
            }
            DataService.ViewDoctor(requestObject);
        }
    }
    render() {
        return (
            <div className="dploginpageBackground" style={{ padding: "100px", }}>

                <center>

                    {/* main div */}
                    <div className="dpmaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "750px", }} className="dpChildDiv">
                            <br />
                            <img src={"data:image/png;base64," + this.state.doctorImage} alt="doctor" className="dpdocimg" />
                            <h1 style={{ color: "black" }}>Doctor Profile</h1><br />
                            <div>
                                <p><b>Name:</b> {this.state.doctorName}</p>
                                <p><b>DOB:</b> {this.state.dob}</p>
                                <p><b>Email:</b> {this.state.doctorEmail}</p>
                                <p><b>Specialization:</b> {this.state.specialization}</p>
                                <p><b>Day:</b> {this.state.day}</p>
                                <p><b>Experience:</b> {this.state.experience}</p>
                                <p><b>Timings:</b> <p>{this.state.startTime.hours + ":" + this.state.startTime.minutes} to {this.state.endTime.hours + ":" + this.state.endTime.minutes} </p></p><br /> <br />
                                {/*{this.state.startTime != null && <p><b>Timings: </b> {this.state.startTime.hours + ":" + this.state.startTime.minutes} to {this.state.endTime.hours + ":" + this.state.endTime.minutes} </p>}<br /><br />*/}
                                <a href="/DoctorHome"><p style={{ color: "blue" }}>Back to Home</p></a>
                            </div><br /><br />

                        </div>
                        {/* image div*/}
                        <div className="dpChildDiv">
                            <center>
                                <br /><br />
                                <img src={login} alt="doctor login pictor" className="dpimgwidth" />
                            </center>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default DoctorDetail;
import React from "react";
import NavBar from "../../main components/navbar";
import Footer from "../../main components/footer";

class DoctorViewAppointment extends React.Component {
    render() {
        return (
            <div>
                <NavBar />
                <div>
                    <div className="homeClassimg">
                        <div className="homeClass1">
                            <h1>welcome Doctor! </h1><br />
                            <p>
                                Medicine cure diseases but only doctors can cure patients
                            </p><br />
                            <p> God can not come for us all the time that's why he sent doctors for us</p><br />
                            <h4>Below are your appointments </h4>
                            <h3>
                            </h3></div>
                    </div>
                    <div style={{ paddingLeft: 170, height: 850, paddingTop: 100, paddingRight: '0%', paddingBottom: 100, backgroundColor: 'rgb(17, 58, 95)' }}>
                        <table>
                            <tbody><tr>
                                <th>Appointment ID</th>
                                <th>Patient Name</th>
                                <th>Doctor Name</th>
                                <th>Date</th>
                                <th>time</th>
                            </tr>
                                <tr>
                                    <td>1</td>
                                    <td>john</td>
                                    <td>Dr. Ram</td>
                                    <td>12/05/2022</td>
                                    <td>12:00 pm</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Ramu</td>
                                    <td>Dr. Ram</td>
                                    <td>12/05/2022</td>
                                    <td>12:30 pm</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Sanju</td>
                                    <td>Dr. Ram</td>
                                    <td>12/05/2022</td>
                                    <td>1:00 pm</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Ashish</td>
                                    <td>Dr. Ram</td>
                                    <td>13/05/2022</td>
                                    <td>12:30 pm</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Sai</td>
                                    <td>Dr. Ram</td>
                                    <td>13/05/2022</td>
                                    <td>12:30 pm</td>
                                </tr>
                            </tbody></table>
                        <br />
                        <a href="/Doctor/Homepage"><button type="button" style={{ borderRadius: 3, color: 'rgb(38, 37, 37)', backgroundColor: 'rgb(247, 191, 191)', border: '1px solid rgb(251, 207, 207)', textAlign: 'center', padding: 5 }}>Go Back</button></a>
                        <br />
                    </div>
                </div>
                <Footer />
            </div>
        );
    }
}

export default DoctorViewAppointment;
import React from "react";
import Del from '../../images/profileDelete.gif';

class DoctorDelete extends React.Component {

    render() {
        return (
            <div>
                <center><br /><br />
                    <h1>Account Deleted!</h1>
                    <img src={Del} width={"600px"} height={"500px"} />

                    <a href="/DoctorInsert">
                        <p><b>Click here to Register!</b></p>
                    </a>
                </center>
            </div>
        );
    }
}

export default DoctorDelete;
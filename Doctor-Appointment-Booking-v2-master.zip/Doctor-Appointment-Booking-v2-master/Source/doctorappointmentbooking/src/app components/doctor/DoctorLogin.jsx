import React from "react";
import DataService from "../../DataService";
import Doc from '../../images/doc.jpg';
import '../../css/login.css';
import login from '../../images/doctorlogin.jpg';

class DoctorLogin extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            DoctorEmail: "",
            DoctorPassword: "",
        }
        this.componentDidMount = () => {
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.state,
                    success: (response) => {

                        this.setState({ LoginDoctor: response });
                        console.log(response);
                        localStorage.setItem("DoctorEmail", this.state.DoctorEmail);
                        localStorage.setItem("DoctorPassword", this.state.DoctorPassword);
                        window.location.href = "/DoctorHome";
                    },
                    error: function (error) {
                        console.log(error);
                        window.location.href = "/DoctorInvalidCredentials";
                    }
                }
                e.preventDefault();
                DataService.LoginDoctor(requestObject);

                //alert("Log In Successfull!");
            }
        }
    }
    render() {
        return (
            <div className="dlloginpageBackground" style={{ padding: "160px", }}>

                <center>
                    {/* main div */}
                    <div className="dlmaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "500px", }} className="dlChildDiv">
                            <br />
                            <img src={Doc} alt="doctor" className="dldocimg" />
                            <h1 style={{ color: "rgb(211, 40, 113)" }}>Doctor Login</h1><br />
                            <form onSubmit={this.onSubmit}>

                                <label className="dlemailstyle" htmlfor="DoctorEmail"><i className="fa-solid fa-user-doctor" ></i> Email</label>
                                <input className="dlfeildwidth" type="email" id="DoctorEmail" name="DoctorEmail" value={this.state.DoctorEmail} onChange={(e) => this.setState({ DoctorEmail: e.target.value })} /><br /><br />
                                <label className="dlpasswordstyle" htmlfor="DoctorPassword"> <i class="fa-solid fa-lock"></i> Password</label>
                                <input className="dlfeildwidth" type="password" id="DoctorPassword" name="DoctorPassword" value={this.state.DoctorPassword} onChange={(e) => this.setState({ DoctorPassword: e.target.value })} /><br /><br />
                                <button type="submit" onClick={this.onSubmit} className="dlloginstyle">Login</button>
                                <br />
                                <br />
                                <h6>Forgot your Password?</h6><a href="/DoctorForgotPassword" style={{ color: "rgb(211, 40, 113)" }}>Click here!</a>
                                <br />
                                <a href="/DoctorInsert" style={{ color: "rgb(211, 40, 113)" }}>
                                    <p style={{ color: "rgb(211, 40, 113)" }}>Don't have an account ? Create here to register!</p>
                                </a>
                            </form>
                        </div>
                        {/* image div*/}
                        <div className="dlChildDiv"><br /><br />
                            <center><img src={login} alt="doctor login pictor" className="dlimgwidth" /></center>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}
export default DoctorLogin;
import React from "react";
import DataService from "../../DataService";
import login from '../../images/doctorlogin.jpg';
import Doc from '../../images/doc.jpg';
import '../../css/doctorupdate.css';

class DoctorEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            DoctorEmail: "",
            DoctorName: "",
            DoctorPassword: "",
            Specialization: "",
            Experience: "",
            Day: "",
            Hospital: "",
            StartTime: "",
            Endtime: "",
            Dob: "",
            DoctorImage: null
        }
        this.componentDidMount = () => {
            this.getFormData = () => {
                const img = new FormData();
                img.append("DoctorEmail", this.state.DoctorEmail);
                img.append("DoctorName", this.state.DoctorName);
                img.append("DoctorPassword", this.state.DoctorPassword);
                img.append("Specialization", this.state.Specialization);
                img.append("Experience", this.state.Experience);
                img.append("Dob", this.state.Dob);
                img.append("Day", this.state.Day);
                img.append("Hospital", this.state.Hospital);
                img.append("StartTime", this.state.StartTime);
                img.append("EndTime", this.state.EndTime);
                img.append("DoctorImage", this.state.DoctorImage);
                return img;
            }
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.getFormData(),
                    success: (response) => {
                        this.setState({ UpdateDoctor: response });
                        //alert("Form Submitted......");
                        //window.location.href = "/DoctorHome";
                    },
                    error: function (error) {
                        console.log(error);
                    }
                }
                e.preventDefault();
                DataService.UpdateDoctor(requestObject);
                alert("Form Submitted!");
                window.location.href = "/DoctorDetailsUpdated";
            }
        }
    }
    render() {
        return (
            <div className="duloginpageBackground" style={{ padding: "250px", }}>

                <center>
                    {/* main div */}
                    <div className="dumaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "1000px", }} className="duChildDiv">
                            <br />
                            <img src={Doc} alt="doctor" className="dudocimg" />
                            <h1 style={{ color: "rgb(211, 40, 113)" }}>Doctor Profile Update</h1><br />
                            <form onSubmit={this.onSubmit}>

                                <label className="duemailstyle"><i className="fa-solid fa-user"></i> Name</label>
                                <input className="dufeildwidth" required type="text" name="DoctorName" id="DoctorName" value={this.state.DoctorName} onChange={(e) => this.setState({ DoctorName: e.target.value })} /><br /><br />

                                <label htmlFor="Dob" className="dudobstyle"><i className="fa-solid fa-calendar-days"></i> DOB</label>
                                <input className="dufeildwidth" required type="date" name="Dob" id="Dob" value={this.state.Dob} onChange={(e) => this.setState({ Dob: e.target.value })} /><br /><br />

                                <label className="duemailstyle" htmlFor="DoctorEmail"><i className="fa-solid fa-envelope"></i> Email</label>
                                <input className="dufeildwidth" type="email" name="DoctorEmail" id="DoctorEmail" value={this.state.DoctorEmail} onChange={(e) => this.setState({ DoctorEmail: e.target.value })} /><br /><br />

                                <label className="dupasswordstyle" htmlFor="DoctorPassword"><i class="fa-solid fa-lock"></i> Password</label>
                                <input className="dufeildwidth" type="password" name="DoctorPassword" id="DoctorPassword" value={this.state.DoctorPassword} onChange={(e) => this.setState({ DoctorPassword: e.target.value })} /><br /><br />

                                <label className="duspestyle"><i className="fa-solid fa-list"></i> Specialization</label>
                                <input className="dufeildwidth" required type="text" name="Specialization" id="Specialization" value={this.state.Specialization} onChange={(e) => this.setState({ Specialization: e.target.value })} /><br /><br />

                                <label className="duexpstyle" htmlFor="Experience"><i class="fa-solid fa-calendar-plus"></i> Experience</label>
                                <input className="dufeildwidth" required type="text" name="Experience" id="Experience" value={this.state.Experience} onChange={(e) => this.setState({ Experience: e.target.value })} /><br /><br />

                                <label className="duhospital" htmlFor="Hospital"><i className="fa-solid fa-house-chimney-medical"></i> Hospital</label>
                                <input className="drfeildwidth" required type="text" name="Hospital" id="Hospital" value={this.state.Hospital} onChange={(e) => this.setState({ Hospital: e.target.value })} /><br /><br />

                                <label className="duhospital" htmlFor="Day"><i className="fa-solid fa-house-chimney-medical"></i> Day</label>
                                <input className="drfeildwidth" required type="text" name="Day" id="Day" value={this.state.Day} onChange={(e) => this.setState({ Day: e.target.value })} /><br /><br />

                                <label className="duhospital" htmlFor="StartTime"><i className="fa-solid fa-house-chimney-medical"></i> Start Time</label>
                                <input className="drfeildwidth" required type="time" name="StartTime" id="StartTime" value={this.state.StartTime} onChange={(e) => this.setState({ StartTime: e.target.value })} /><br /><br />

                                <label className="duhospital" htmlFor="EndTime"><i className="fa-solid fa-house-chimney-medical"></i> End Time</label>
                                <input className="drfeildwidth" required type="time" name="EndTime" id="EndTime" value={this.state.EndTime} onChange={(e) => this.setState({ EndTime: e.target.value })} /><br /><br />

                                <label htmlFor="DoctorImage" className="dupicstyle"> <i className="fa-solid fa-image"></i> Profile Picture</label>
                                <input type="file" name="DoctorImage" id="DoctorImage" className="dupicfeildwidth" required onChange={(e) => this.setState({ DoctorImage: e.target.files[0] })} /><br /><br />

                                <button type="submit" onClick={this.onSubmit} className="duloginstyle">Update my details!</button>
                                <br />
                                <a href="/DoctorHome"><p style={{ color: "rgb(211, 40, 113)" }}>Back to home</p></a>
                                <br />


                            </form>
                        </div>
                        {/* image div*/}
                        <div className="duChildDiv">
                            <center>
                                <br /><br /><br /><br /><br /><br /><br /><br />
                                <img src={login} alt="doctor login pictor" className="duimgwidth" />
                            </center>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default DoctorEdit;
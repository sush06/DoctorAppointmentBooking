import React from "react";

class DoctorViewAppointments extends React.Component {
    render() {
        return (
            <div>
                <h4>Below are your appointments</h4>
                <div style={{ paddingLeft: 170, height: 850, paddingTop: 100, paddingRight: '0%', paddingBottom: 100, backgroundColor: 'rgb(17, 58, 95)' }}>
                    <table>
                        <tbody><tr>
                            <th>Appointment ID</th>
                            <th>Patient Name</th>
                            <th>Doctor Name</th>
                            <th>Date</th>
                            <th>time</th>
                        </tr>
                            <tr>
                                <td>1</td>
                                <td>john</td>
                                <td>Dr. Ram</td>
                                <td>12/05/2022</td>
                                <td>12:00 pm</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Ramu</td>
                                <td>Dr. Ram</td>
                                <td>12/05/2022</td>
                                <td>12:30 pm</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Sanju</td>
                                <td>Dr. Ram</td>
                                <td>12/05/2022</td>
                                <td>1:00 pm</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Ashish</td>
                                <td>Dr. Ram</td>
                                <td>13/05/2022</td>
                                <td>12:30 pm</td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>Sai</td>
                                <td>Dr. Ram</td>
                                <td>13/05/2022</td>
                                <td>12:30 pm</td>
                            </tr>
                        </tbody></table>
                    <br />
                    <a href="/DoctorHome"><button type="button" style={{ borderRadius: 3, color: 'rgb(38, 37, 37)', backgroundColor: 'rgb(247, 191, 191)', border: '1px solid rgb(251, 207, 207)', textAlign: 'center', padding: 5 }}>Go Back</button></a>
                    <br />
                </div>
            </div>
        );
    }
}

export default DoctorViewAppointments;
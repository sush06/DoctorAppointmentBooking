import React from "react";
import DataService from "../../DataService";
import login from '../../images/doctorlogin.jpg';
import Doc from '../../images/doc.jpg';
import '../../css/doctorRegistration.css';


class DoctorInsert extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            DoctorEmail: "",
            DoctorName: "",
            DoctorPassword: "",
            Specialization: "",
            Experience: "",
            Day: "",
            Hospital: "",
            StartTime: "",
            Endtime: "",
            Dob: "",
            DoctorImage: ""
        }
        this.componentDidMount = () => {
            this.getFormData = () => {
                const img = new FormData();
                img.append("DoctorEmail", this.state.DoctorEmail);
                img.append("DoctorName", this.state.DoctorName);
                img.append("DoctorPassword", this.state.DoctorPassword);
                img.append("Specialization", this.state.Specialization);
                img.append("Experience", this.state.Experience);
                img.append("Dob", this.state.Dob);
                img.append("Day", this.state.Day);
                img.append("Hospital", this.state.Hospital);
                img.append("StartTime", this.state.StartTime);
                img.append("EndTime", this.state.EndTime);
                img.append("DoctorImage", this.state.DoctorImage);
                return img;
            }
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.getFormData(),
                    success: (response) => {
                        this.setState({ InsertDoctor: response });
                    },
                    error: function (error) {
                        console.log(error)
                    }
                }
                e.preventDefault();
                DataService.InsertDoctor(requestObject);
                alert("Form Submitted!");
                window.location.href = "/DoctorLogin";
            }
        }
    }
    render() {
        return (
            <div className="drloginpageBackground" style={{ padding: "100px", }}>

                <center>
                    {/* main div */}
                    <div className="drmaindiv">
                        {/* form div */}
                        <div style={{ padding: "3px", backgroundColor: "white", width: "400px", height: "1000px", }} className="drChildDiv">
                            <br />
                            <img src={Doc} alt="doctor" className="drdocimg" />
                            <h1 style={{ color: "rgb(211, 40, 113)" }}>Doctor Registration</h1><br />
                            <form onSubmit={this.onSubmit}>

                                <label className="dremailstyle"><i className="fa-solid fa-user"></i> Name</label>
                                <input type="text" className="drfeildwidth" name="DoctorName" id="DoctorName" value={this.state.DoctorName} onChange={(e) => this.setState({ DoctorName: e.target.value })} required /><br /><br />

                                <label htmlFor="Dob" className="drdobstyle"><i className="fa-solid fa-calendar-days"></i> DOB</label>
                                <input type="date" className="drfeildwidth" name="Dob" id="Dob" value={this.state.Dob} onChange={(e) => this.setState({ Dob: e.target.value })} required /><br /><br />

                                <label className="dremailstyle" htmlfor="emailid"><i className="fa-solid fa-envelope"></i> Email</label>
                                <input type="email" className="drfeildwidth" name="DoctorEmail" id="DoctorEmail" value={this.state.DoctorEmail} onChange={(e) => this.setState({ DoctorEmail: e.target.value })} /><br /><br />

                                <label className="drpasswordstyle" htmlfor="password"><i class="fa-solid fa-lock"></i> Password</label>
                                <input type="password" className="drfeildwidth" name="DoctorPassword" id="DoctorPassword" value={this.state.DoctorPassword} onChange={(e) => this.setState({ DoctorPassword: e.target.value })} /><br /><br />

                                <label htmlFor="Dob" className="drdobstyle"><i className="fa-solid fa-calendar-days"></i>Days</label>
                                <input type="text" className="drfeildwidth" name="Day" id="Day" value={this.state.Day} onChange={(e) => this.setState({ Day: e.target.value })} required /><br /><br />


                                <label className="drpasswordstyle" htmlfor="password"><i class="fa-solid fa-hourglass-start"></i> Start Time</label>
                                <input className="drfeildwidth" type="time" name="StartTime" id="StartTime" value={this.state.StartTime} onChange={(e) => this.setState({ StartTime: e.target.value })} /><br /><br />

                                <label className="drpasswordstyle" htmlfor="password"><i class="fa-solid fa-hourglass-end"></i> End Time</label>
                                <input className="drfeildwidth" name="EndTime" type="time" id="EndTime" value={this.state.EndTime} onChange={(e) => this.setState({ EndTime: e.target.value })} /><br /><br />


                                <label className="drspestyle"><i className="fa-solid fa-list"></i> Specialization</label>
                                <input type="text" className="drfeildwidth" name="Specialization" id="Specialization" value={this.state.Specialization} onChange={(e) => this.setState({ Specialization: e.target.value })} required /><br /><br />

                                <label className="drexpstyle" htmlFor="Experience"><i class="fa-solid fa-calendar-plus"></i> Experience</label>
                                <input className="drfeildwidth" required name="Experience" type="text" id="Experience" value={this.state.Experience} onChange={(e) => this.setState({ Experience: e.target.value })} /><br /><br />

                                <label className="drhospital" htmlFor="hospital"><i className="fa-solid fa-house-chimney-medical"></i> Hospital</label>
                                <input className="drfeildwidth" name="Hospital" type="text" id="Hospital" value={this.state.Hospital} onChange={(e) => this.setState({ Hospital: e.target.value })} required /><br /><br />


                                <label htmlFor="DoctorImage" className="drpicstyle"><i className="fa-solid fa-image"></i> Profile Picture</label>
                                <input className="drpicfeildwidth" required type="file" name="DoctorImage" id="DoctorImage" onChange={(e) => this.setState({ DoctorImage: e.target.files[0] })} /><br /><br />

                                <button type="button" onClick={this.onSubmit} className="drloginstyle">Register</button><br />
                                <br />

                                <a href="/DoctorLogin" style={{ color: "rgb(211, 40, 113)" }}>
                                    <p style={{ color: "rgb(211, 40, 113)" }}>Already have an account? <br />Click here to login!</p>
                                </a>
                            </form>
                        </div>
                        {/* image div*/}
                        <div className="drChildDiv">
                            <center>
                                <br /><br /><br /><br /><br /><br /><br /><br />
                                <img src={login} alt="doctor login pictor" className="drimgwidth" />
                            </center>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default DoctorInsert;
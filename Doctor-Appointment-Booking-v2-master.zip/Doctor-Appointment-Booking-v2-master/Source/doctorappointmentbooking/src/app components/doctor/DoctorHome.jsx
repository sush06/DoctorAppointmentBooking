import React from "react";
import DataService from "../../DataService";
import login from '../../images/DoctorProfile.jpg';
import Del from '../../images/profileDelete.gif';
import Pat from '../../images/patientReg.jpg';
import Doc1 from '../../images/patient1.jpg';
import Doc2 from '../../images/patient2.jpg';
import Doc3 from '../../images/patient6.jpeg';
import Doc5 from '../../images/patient7.jpeg';
import Gif from '../../images/DoctorHome.gif';

class DoctorHome extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            DoctorEmail: ""
        }
    }
    onSubmit = (e) => {
        e.preventDefault();
        var tmp = localStorage.getItem("DoctorEmail");
        var requestObject = {
            data: { DoctorEmail: tmp },
            success: (response) => {
                console.log(response);
                localStorage.removeItem("DoctorEmail");
                window.location.href = "/DoctorDelete";
            },
            error: function (error) {
                console.log(error);
                window.location.href = "/DoctorInvalidCredentials";
            }
        }
        DataService.DeleteDoctor(requestObject);
        alert("Delete Successful!");
    }

    render() {
        return (
            <div>

                <center>
                    <img src={Gif} width={"100%"} height={"700px"} />
                </center>
                <div style={{ background: "black", padding: "100px", height: "500px" }}>
                    <div className="pChildDiv">
                        <center><h1 style={{ color: "white" }}>Welcome to Medic'O</h1></center><br />
                        <center>

                            <ul>

                                <li><h4 style={{ color: "white", textAlign: "justify" }}>Welcome To Medic'O Family Practice and the<br /> office of Medic'O</h4></li><br />
                                <li><h4 style={{ color: "white", textAlign: "justify" }}>Medic'O Helps You To Sever Many People We are<br /> Happy To Have You With US </h4></li>

                            </ul>
                        </center>
                    </div>

                    <div style={{ width: "150px", textAlign: "center" }} className="pChildDiv"></div>

                    <div style={{ width: "250px", height: "200px", borderRadius: "10px", border: "3px solid white", background: "white", textAlign: "center" }} className="pChildDiv">
                        <center><br />
                            <a href="/DoctorDetail">
                                <button className="buttoncss">Profile View</button></a><br />
                            <a href="/DoctorEdit">
                                <button className="buttoncss">Profile Update</button></a><br />

                            <button className="buttoncss" type="button" onClick={this.onSubmit} >Delete Profile</button><br /><br />
                        </center>
                    </div>
                </div>

                {/* cards*/}
                <div className="cardpadding">
                    <div style={{ paddingLeft: "180px" }}>
                        <br />
                        <br />
                        <center><h2>Your Appointments</h2></center><br /><br />
                        <div style={{ padding: "0px", borderRadius: "10px", border: "2px solid lightgrey", width: "260px", height: "450px", padding: "10px", boxShadow: "5px 5px 10px rgb(204, 203, 203) ", background: "white" }} className="cardChildDiv">
                            <img src={Doc1} width={"230px"} height={"200px"} /><br /><br />
                            <div className="infocss">
                                <center>
                                    <p style={{ textAlign: "justify" }}>Name: P. Teju </p>
                                    <p style={{ textAlign: "justify" }}>Illness: Ear Pain</p>
                                    <p style={{ textAlign: "justify" }}>Mode: Online</p>
                                    <p style={{ textAlign: "justify" }}>Time: 10:00AM</p>
                                    <p style={{ textAlign: "justify" }}>Day: Mon</p>
                                </center>
                            </div>
                        </div>
                        <div style={{ width: "30px", height: "390px" }} className="cardChildDiv"></div>
                        <div style={{ padding: "0px", borderRadius: "10px", border: "2px solid white", width: "260px", height: "450px", padding: "10px", boxShadow: "5px 5px 10px rgb(204, 203, 203)", background: "white" }} className="cardChildDiv">
                            <img src={Doc2} width={"230px"} height={"200px"} /><br /><br />
                            <div className="infocss">
                                <center>
                                    <p style={{ textAlign: "justify" }}>Name: A. Rahul </p>
                                    <p style={{ textAlign: "justify" }}>Illness: Ear Pain</p>
                                    <p style={{ textAlign: "justify" }}>Mode: Online</p>
                                    <p style={{ textAlign: "justify" }}>Time: 3:30pm</p>
                                    <p style={{ textAlign: "justify" }}>Day: Mon</p>
                                </center>
                            </div>
                        </div>
                        <div style={{ width: "30px", height: "390px" }} className="cardChildDiv"></div>
                        <div style={{ padding: "0px", borderRadius: "10px", border: "2px solid white", width: "260px", height: "450px", padding: "10px", boxShadow: "5px 5px 10px rgb(204, 203, 203)", background: "white" }} className="cardChildDiv">
                            <img src={Doc3} width={"230px"} height={"200px"} /><br /><br />
                            <div className="infocss">
                                <center>
                                    <p style={{ textAlign: "justify" }}>Name: Kavya</p>
                                    <p style={{ textAlign: "justify" }}>Illness: Tooth Pain</p>
                                    <p style={{ textAlign: "justify" }}>Mode: Online</p>
                                    <p style={{ textAlign: "justify" }}>Time: 2:30pm</p>
                                    <p style={{ textAlign: "justify" }}>Day: Wed</p>
                                </center>
                            </div>
                        </div>
                        <div style={{ width: "30px", height: "390px" }} className="cardChildDiv"></div>
                        <div style={{ padding: "0px", borderRadius: "10px", border: "2px solid white", width: "260px", height: "450px", padding: "10px", boxShadow: "5px 5px 10px rgb(204, 203, 203)", background: "white" }} className="cardChildDiv">
                            <img src={Doc5} width={"230px"} height={"200px"} /><br /><br />
                            <div className="infocss">
                                <center>
                                    <p style={{ textAlign: "justify" }}>Name: K. Saketh </p>
                                    <p style={{ textAlign: "justify" }}>Illness:  Root canal</p>
                                    <p style={{ textAlign: "justify" }}>Mode: Online</p>
                                    <p style={{ textAlign: "justify" }}>Time: 11:00AM</p>
                                    <p style={{ textAlign: "justify" }}>Day: Mon</p>

                                </center>
                            </div>
                        </div><br /><br /><br /><br /><br />
                    </div>
                </div>
                <center>
                    <a href="/DoctorLogin">
                        <button style={{ background: "black", color: "white", padding: "10px" }}>LogOut</button><br /><br /></a></center>
            </div>
        );
    }
}

export default DoctorHome;
import React from "react";
import DataService from "../../DataService";
import Gif from '../../images/forgotpassword.gif';
import "../../css/patientRegistration.css";


class DoctorForgotPassword extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            DoctorEmail: "",
        }
        this.componentDidMount = () => {
            this.onSubmit = (e) => {
                var requestObject = {
                    data: this.state,
                    success: (response) => {
                        this.setState({ DoctorForgotPassword: response });
                        console.log(response);
                        alert("Mail sent. Please check your email!");
                        //window.location.href = "/PatientHome";
                    },
                    error: function (error) {
                        console.log(error);
                        window.location.href = "/DoctorInvalidCredentials";
                    }
                }
                e.preventDefault();
                DataService.DoctorForgotPassword(requestObject);
                //alert("Log In Successfull!");

            }
        }
    }
    render() {
        return (
            <div style={{ height: "100vh" }}>
                <center>
                    <br />
                    <img src={Gif} width={"40%"} height={"350px"} /><br />
                    <br />
                    <h3>Enter your email ID below to reset your password!</h3>
                    <form onSubmit={this.onSubmit}>
                        <label htmlFor="DoctorEmail" className="premailstyle">Email</label>
                        <input id="DoctorEmail" name="DoctorEmail" type="text" value={this.state.DoctorEmail} onChange={(e) => this.setState({ DoctorEmail: e.target.value })} required placeholder="Email" className="loginClass" /><br /><br />
                        <div style={{ paddingLeft: 50 }}>
                            <button type="submit" style={{ borderRadius: 3, color: 'rgb(0, 0, 0)', backgroundColor: 'dodgerblue', border: '1px solid dodgerblue', textAlign: 'center', padding: 5 }}>Submit</button>
                        </div>
                    </form>
                </center>
            </div>
        );
    }
}

export default DoctorForgotPassword;
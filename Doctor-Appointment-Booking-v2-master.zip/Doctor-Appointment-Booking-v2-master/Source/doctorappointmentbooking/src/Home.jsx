import React from "react";
import home from '../src/css/home.css';
import Gif from './images/HOMEgif2.gif';
import Doc1 from './images/doctorProfileimg.jpg';
import Doc2 from './images/doc2.jpg';
import Doc3 from './images/doc3.jpg';
import Doc5 from './images/doc5.jpg';
import HomeDashboard from './HomeDashBoard';
import DataService from "./DataService";
import './css/appointmentBooking.css';
class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            doctor: []
        }
        this.componentDidMount = () => {
            var object = {
                success: (response) => {
                    console.log(response);
                    this.setState({ doctor: response });
                },
                error: function (error) {
                    console.log(error);
                }
            }
            DataService.ListDoctors(object);
        }
    }
    render() {
        return (
            <div>
                <center>
                    <img src={Gif} width={"70%"} height={"600px"} />
                </center><br /><br />
                <div>

                    <div className="wellcomecss">
                        <center>
                            <br /><br />
                            <h1>Welcome! to Medic'O </h1>
                            <p>
                                Looking for an appointment right at your destination. Get Confirmed
                                Appointment with Top Doctors and Surgeons in Hyderabad at Preferred
                                Date &amp; Time.
                                <br />
                                <br /> Get Confirmed Appointment with Experienced Doctors &amp; Surgeons.
                                Book Now! 12+ Centers of Excellence. Cutting-Edge Treatment.
                            </p>
                            <h4>Get the Personal care for your healthy living. </h4><br />
                            <a href="/PatientLogin">
                                <button type="button" className="buttoncss">Book Appointment</button></a>
                        </center>
                    </div>



                </div>

                <center>

                    {
                        this.state.doctor.map((doctor) =>
                            <div className="cardChildDiv" ><br /><br /><br />
                                <div style={{ padding: "0px", borderRadius: "10px", border: "2px solid lightgry", width: "250px", height: "600px", padding: "10px", boxShadow: "5px 5px 10px rgb(204, 203, 203) ", background: "white" }} className="cardChildDiv">
                                    <img src={"data:image/png;base64," + doctor.doctorImage} width={"230px"} height={"200px"} /><br /><br />
                                    <div className="infocss">
                                        <p><b>Doctor Name:</b> {doctor.doctorName} </p>
                                        <p><b>Specialization:</b> {doctor.specialization}</p>
                                        <p><b>Experience:</b> {doctor.experience}</p>
                                        <p><b>Hospital:</b> {doctor.hospital}</p>
                                        <p><b>Day: </b>{doctor.day}</p>
                                        <p><b>Email:</b> {doctor.doctorEmail} </p>
                                        {doctor.startTime != null && <p><b>Timings: </b> {doctor.startTime.hours + ":" + doctor.startTime.minutes} to {doctor.endTime.hours + ":" + doctor.endTime.minutes} </p>}
                                    </div>
                                </div>
                                <div style={{ width: "30px", height: "390px" }} className="cardChildDiv"></div>
                            </div>
                        )
                    }
                    <br />
                    <br />
                    <HomeDashboard />
                </center>
            </div>
        );
    }
}

export default Home;
import axios from "axios";
import emailjs from 'emailjs-com';
const apiUrl = "http://localhost:32469/";

var DataService = {
    InsertDoctor: (requestObject) => {
        axios.post(apiUrl + "api/Doctor/InsertDoctor", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    InsertPatient: (requestObject) => {
        axios.post(apiUrl + "api/Patient/InsertPatient", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    LoginPatient: (requestObject) => {
        axios.post(apiUrl + "api/Patient/LoginPatient", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    LoginDoctor: (requestObject) => {
        axios.post(apiUrl + "api/Doctor/LoginDoctor", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    PatientForgotPassword: (requestObject) => {
        axios.post(apiUrl + "api/Patient/PatientForgetPassword", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
                console.log(requestObject);
                console.log(response.data);
                if (response.data.status === "Success") {
                    emailjs.send('service_1h2eibb', 'template_zx9aklp', requestObject, 'ZMM8S2J3fDmiqUrRE')
                        .then((result) => {
                            console.log(result.text);
                        }, (error) => {
                            console.log(error.text);
                        });
                }
                else {
                    //window.location.href = "/InvalidCredentials";
                    console.log(response);
                }
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    PatientResetPassword: (requestObject) => {
        axios.post(apiUrl + "api/Patient/PatientResetPassword", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
                console.log(requestObject);
                console.log(response.data);
                if (response.data.status === "Success") {
                    emailjs.send('service_1h2eibb', 'template_ks3ddup', requestObject, 'ZMM8S2J3fDmiqUrRE')
                        .then((result) => {
                            console.log(result.text);
                        }, (error) => {
                            console.log(error.text);
                        });
                }
                else {
                    //window.location.href = "/InvalidCredentials";
                    console.log(response);
                }
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    DoctorForgotPassword: (requestObject) => {
        axios.post(apiUrl + "api/Doctor/DoctorForgetPassword", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
                console.log(requestObject);
                console.log(response.data);
                if (response.data.status === "Success") {
                    emailjs.send('service_1h2eibb', 'template_svamv2b', requestObject, 'ZMM8S2J3fDmiqUrRE')
                        .then((result) => {
                            console.log(result.text);
                        }, (error) => {
                            console.log(error.text);
                        });
                }
                else {
                    //window.location.href = "/InvalidCredentials";
                    console.log(response);
                }
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    DoctorResetPassword: (requestObject) => {
        axios.post(apiUrl + "api/Doctor/DoctorResetPassword", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
                console.log(requestObject);
                console.log(response.data);
                if (response.data.status === "Success") {
                    emailjs.send('service_1h2eibb', 'template_ks3ddup', requestObject, 'ZMM8S2J3fDmiqUrRE')
                        .then((result) => {
                            console.log(result.text);
                        }, (error) => {
                            console.log(error.text);
                        });
                }
                else {
                    //window.location.href = "/InvalidCredentials";
                    console.log(response);
                }
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    DeleteDoctor: (requestObject) => {
        axios.post(apiUrl + "api/Doctor/DeleteDoctor", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    DeletePatient: (requestObject) => {
        axios.post(apiUrl + "api/Patient/DeletePatient", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    UpdateDoctor: (requestObject) => {
        axios.post(apiUrl + "api/Doctor/UpdateDoctor", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    UpdatePatient: (requestObject) => {
        axios.post(apiUrl + "api/Patient/UpdatePatient", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    ListHospitals: (requestObject) => {
        axios.get(apiUrl + "api/Doctor/ListHospitals", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    DoctorHospitalInsert: (requestObject) => {
        axios.post(apiUrl + "api/Doctor/DoctorHospitalInsert", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    ViewDoctor: (requestObject) => {
        axios.get(apiUrl + "api/Doctor/ViewDoctor/" + requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    ViewPatient: (requestObject) => {
        axios.get(apiUrl + "api/Patient/ViewPatient/" + requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    ViewAppointment: (requestObject) => {
        axios.get(apiUrl + "api/Patient/ViewAppointment/" + requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    BookAppointment: (requestObject) => {
        axios.post(apiUrl + "api/Patient/BookAppointment", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            })
    },
    DeleteAppointment: (requestObject) => {
        axios.post(apiUrl + "api/Patient/DeleteAppointment", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    UpdateAppointment: (requestObject) => {
        axios.post(apiUrl + "api/Patient/UpdateAppointment", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    BookAppointmentSuccessful: (requestObject) => {
        axios.post(apiUrl + "api/Patient/BookAppointmentSuccessful", requestObject.data)
            .then(function (response) {
                requestObject.success(response.data);
                console.log(requestObject);
                console.log(response.data);
                if (response.data.status === "Success") {
                    emailjs.send('service_aq81dwa', 'template_vbb4cpi', requestObject, 'xR0vCet3ePPD7VLBZ')
                        .then((result) => {
                            console.log(result.text);
                        }, (error) => {
                            console.log(error.text);
                        });
                }
                else {
                    //window.location.href = "/InvalidCredentials";
                    console.log(response);
                }
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },
    ListDoctors: (requestObject) => {
        axios.get(apiUrl + "api/Doctor/ListDoctors")
            .then(function (response) {
                requestObject.success(response.data);
            })
            .catch(function (error) {
                requestObject.error(error);
            });
    },

}

export default DataService;

function App() {
  return (
    <div className="App">
      This is a React App!

    </div>
  );
}

export default App;

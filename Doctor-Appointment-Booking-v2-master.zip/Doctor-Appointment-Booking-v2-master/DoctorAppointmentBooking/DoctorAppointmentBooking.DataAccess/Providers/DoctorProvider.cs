﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorAppointmentBooking.DataAccess.Models;

namespace DoctorAppointmentBooking.DataAccess.Providers
{
    public class DoctorProvider
    {
        public List<Doctor> ListDoctors()
        {
            using(var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
            {
                return dbContext.Doctors.ToList();
            }
        }

        public Doctor GetDoctor(string doctorEmail)
        {
            using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
            {
                return dbContext.Doctors.Where(m => m.DoctorEmail == doctorEmail).FirstOrDefault();
            }
        }

        public Doctor InsertDoctor(string doctorEmail, string doctorPassword, string doctorName, DateTime dob, string specialization, int experience,string hospital, string day, TimeSpan startTime, TimeSpan endTime ,  byte[] doctorImage)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    Doctor doctor = new Doctor();
                    doctor.DoctorEmail = doctorEmail;
                    doctor.DoctorPassword = doctorPassword;
                    doctor.DoctorName = doctorName;
                    doctor.Dob = dob;
                    doctor.Specialization = specialization;
                    doctor.Experience = experience;
                    doctor.Day = day;
                    doctor.StartTime = startTime;
                    doctor.EndTime = endTime;
                    doctor.Hospital = hospital;
                    doctor.DoctorImage = doctorImage;
                    dbContext.Doctors.Add(doctor);
                    dbContext.SaveChanges();
                    return doctor;
                }
                

            }
            catch
            {
                throw;
            }
        }

        public Doctor LoginDoctor(string doctorEmail, string doctorPassword)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var user = (from b in dbContext.Doctors
                                where b.DoctorEmail == doctorEmail &&
                                b.DoctorPassword == doctorPassword
                                select b).FirstOrDefault();
                    return user;
                }
            }
            catch
            {
                throw;
            }
        }


        public Doctor UpdateDoctor(string doctorEmail, string doctorPassword, string doctorName, DateTime dob, string specialization, int experience, string hospital, string day, TimeSpan startTime, TimeSpan endTime, byte[] doctorImage)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var doctor = (from b in dbContext.Doctors
                                  where b.DoctorEmail == doctorEmail
                                  select b).FirstOrDefault();
                        doctor.DoctorEmail = doctorEmail;
                        doctor.DoctorPassword = doctorPassword;
                        doctor.DoctorName = doctorName;
                        doctor.Dob = dob;
                        doctor.Specialization = specialization;
                        doctor.Experience = experience;
                        doctor.Day = day;
                        doctor.StartTime = startTime;
                        doctor.EndTime = endTime;
                        doctor.Hospital = hospital;
                        doctor.DoctorImage = doctorImage;
                        dbContext.Doctors.Update(doctor);
                        dbContext.SaveChanges();
                    return doctor;
                }
                
            }
            catch
            {
                throw;
            }
        }


        public Doctor DeleteDoctor(string doctorEmail)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var doctor = (from b in dbContext.Doctors
                                  where b.DoctorEmail == doctorEmail
                                  select b).FirstOrDefault();

                    dbContext.Doctors.Remove(doctor);
                    dbContext.SaveChanges();
                    return doctor;
                }
            }
            catch
            {
                throw;
            }
        }

        //public Hospital GetHospital(string hospitalName)
        //{
        //    using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
        //    {
        //        return dbContext.Hospitals.Where(m => m.HospitalName == hospitalName).FirstOrDefault();
        //    }
        //}

        //public List<Hospital> ListHospitals()
        //{
        //    using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
        //    {
        //        return dbContext.Hospitals.ToList();
        //    }
        //}

        public bool DoctorHospitalInsert(string doctorEmail, string hospitalName)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    DocHospital docHospital = new DocHospital();
                    docHospital.DoctorEmail = doctorEmail;
                    docHospital.HospitalName = hospitalName;
                }
                return true;
            }
            catch
            {
                throw;
            }
        }

        public bool GetProfilePicture(string doctorEmail, byte[] doctorImage)
        {

            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var dp = (from b in dbContext.Doctors
                              where b.DoctorEmail == doctorEmail
                              select b).FirstOrDefault();
                    dp.DoctorImage = doctorImage;
                }
                return true;
            }
            catch
            {
                throw;
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorAppointmentBooking.DataAccess.Models;

namespace DoctorAppointmentBooking.DataAccess.Providers
{
    public class AppointmentProvider
    {
        public bool BookAppointment(string patientEmail, string doctorName, string day, string appointmentMode, TimeSpan time, byte[] medicalReports)
        {
            try
            {
                using(var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    Appointment appointment = new Appointment();
                    appointment.PatientEmail = patientEmail;
                    appointment.DoctorName = doctorName;
                    appointment.Day = day;
                    appointment.AppointmentMode = appointmentMode;
                    appointment.Time = time;
                    appointment.MedicalReports = medicalReports;
                    dbContext.Appointments.Add(appointment);
                    dbContext.SaveChanges();
                }
                return true;
            }
            catch
            {
                throw;
            }
        }


        public Appointment GetAppointment(string patientEmail)
        {
            using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
            {
                return dbContext.Appointments.Where(m => m.PatientEmail == patientEmail).FirstOrDefault();
            }
        }

        public bool UpdateAppointment(string patientEmail, string doctorName, string day, string appointmentMode, TimeSpan time, byte[] medicalReports)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var appointment = (from b in dbContext.Appointments
                                  where b.PatientEmail == patientEmail
                                       select b).FirstOrDefault();
                    appointment.DoctorName = doctorName;
                    appointment.Day = day;
                    appointment.Time = time;
                    appointment.MedicalReports = medicalReports;
                    appointment.AppointmentMode = appointmentMode;
                    dbContext.Appointments.Update(appointment);
                    dbContext.SaveChanges();
                    
                }
                return true;
            }
            catch
            {
                throw;
            }
        }


        public bool DeleteAppointment(string patientEmail)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var appointment = (from b in dbContext.Appointments
                                        where b.PatientEmail == patientEmail
                                       select b).FirstOrDefault();

                    dbContext.Appointments.Remove(appointment);
                    dbContext.SaveChanges();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Appointment> ListAppointments()
        {
            using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
            {
                return dbContext.Appointments.ToList();
            }
        }
    }
}

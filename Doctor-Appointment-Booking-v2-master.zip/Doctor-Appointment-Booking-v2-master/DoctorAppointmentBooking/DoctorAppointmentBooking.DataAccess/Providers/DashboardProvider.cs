﻿using DoctorAppointmentBooking.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentBooking.DataAccess.Providers
{
    public class DashboardProvider
    {
        public int doctorCount()
        {
            DoctorProvider doctorProvider = new DoctorProvider();
            List<Doctor> dcount = doctorProvider.ListDoctors();
            int d=0;
            foreach(Doctor i in dcount)
            {
                if(i.DoctorId > 1)
                {
                    d++;
                }
                else
                {
                    continue;
                }
            }
            return d;
        }



        public int patientCount()
        {
            PatientProvider patientProvider = new PatientProvider();
            List<Patient> pcount = patientProvider.ListPatients();
            int p = 0;
            foreach (Patient i in pcount)
            {
                if (i.PatientId > 1)
                {
                    p++;
                }
                else
                {
                    continue;
                }
            }
            return p;
        }
        public int appointmentCount()
        {
            AppointmentProvider appointmentProvider = new AppointmentProvider();
            List<Appointment> acount = appointmentProvider.ListAppointments();
            int a = 0;
            foreach (Appointment i in acount)
            {
                if (i.AppointmentId > 1)
                {
                    a++;
                }
                else
                {
                    continue;
                }
            }
            return a;
        }

        public List<Count> AppCount()
        {
            using (var db = new DOCTORAPPOINTMENTBOOKINGContext())
            {
                var i = (from l in (from k in (from s in db.Doctors
                                               join st in db.Appointments
                                               on s.DoctorName equals st.DoctorName
                                               select new
                                               {
                                                   name = s.DoctorName,
                                                   Id = st.AppointmentId
                                               })
                                    group k by k.name)
                         orderby l.Count() descending
                         select new { doctorName = l.Key, Counts = l.Count() });

                List<Count> c = new List<Count>();
                foreach (var item in i)
                {
                    c.Add(new Count(item.doctorName, item.Counts));
                }
                return c;
            }
        }

    }
}

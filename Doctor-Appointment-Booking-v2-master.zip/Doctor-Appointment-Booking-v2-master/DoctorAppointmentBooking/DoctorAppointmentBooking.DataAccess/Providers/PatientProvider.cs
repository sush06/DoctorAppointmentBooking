﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorAppointmentBooking.DataAccess.Models;

namespace DoctorAppointmentBooking.DataAccess.Providers
{
    public class PatientProvider
    {
        public List<Patient> ListPatients()
        {
            using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
            {
                return dbContext.Patients.ToList();
            }
        }

        public Patient GetPatient(string patientEmail)
        {
            using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
            {
                return dbContext.Patients.Where(m => m.PatientEmail == patientEmail).FirstOrDefault();
            }
        }

        public bool InsertPatient(string patientEmail, string patientPassword, string patientName, DateTime dob, string disease, byte[] patientImage)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    Patient patient = new Patient();
                    patient.PatientEmail = patientEmail;
                    patient.PatientPassword = patientPassword;
                    patient.PatientName = patientName;
                    patient.Dob = dob;
                    patient.Disease = disease;
                    patient.PatientImage = patientImage;
                    dbContext.Patients.Add(patient);
                    dbContext.SaveChanges();
                }
                return true;
            }
            catch
            {
                throw;
            }
        }

        public Patient LoginPatient(string patientEmail, string patientPassword)
        {
            try
            {
                using(var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var user = (from b in dbContext.Patients
                                where b.PatientEmail == patientEmail &&
                                b.PatientPassword == patientPassword
                                select b).FirstOrDefault();
                    return user;
                }
            }
            catch
            {
                throw;
            }
        }



        public Patient UpdatePatient(string patientEmail, string patientPassword, string patientName, DateTime dob, string disease, byte[] patientImage)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var patient = (from b in dbContext.Patients
                                   where b.PatientEmail == patientEmail
                                   select b).FirstOrDefault();
                        patient.PatientEmail = patientEmail;
                        patient.PatientPassword = patientPassword;
                        patient.PatientName = patientName;
                        patient.Dob = dob;
                        patient.Disease = disease;
                        patient.PatientImage = patientImage;
                        dbContext.Patients.Update(patient);
                        dbContext.SaveChanges();
                    return patient;
                }
            }
            catch
            {
                throw;
            }
        }

        public bool DeletePatient(string patientEmail)
        {
            try
            {
                using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
                {
                    var patient = (from b in dbContext.Patients
                                   where b.PatientEmail == patientEmail
                                   select b).FirstOrDefault();

                    dbContext.Patients.Remove(patient);
                    dbContext.SaveChanges();
                }
                return true;
            }
            catch
            {
                throw;
            }
        }

        public Appointment GetAppointment(string patientEmail)
        {
            using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
            {
                return dbContext.Appointments.Where(m => m.PatientEmail == patientEmail).FirstOrDefault();
            }
        }
        //Function to View all the patient's appointments.
        //public Appointment ViewAppointments(int patientId)
        //{
        //    using (var dbContext = new DOCTORAPPOINTMENTBOOKINGContext())
        //    {
        //        return dbContext.Appointments.Where(m => m.PatientId == patientId).FirstOrDefault();
        //    }
        //}
    }
}

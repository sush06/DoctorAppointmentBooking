﻿using System;

namespace DoctorAppointmentBooking.DataAccess
{
    public class Class1
    {
    }
}

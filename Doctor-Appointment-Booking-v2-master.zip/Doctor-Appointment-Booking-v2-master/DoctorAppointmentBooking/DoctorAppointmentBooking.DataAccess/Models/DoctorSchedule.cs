﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DoctorAppointmentBooking.DataAccess.Models
{
    public partial class DoctorSchedule
    {
        public int DoctorId { get; set; }
        public int HospitalId { get; set; }
        public string Day { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
    }
}

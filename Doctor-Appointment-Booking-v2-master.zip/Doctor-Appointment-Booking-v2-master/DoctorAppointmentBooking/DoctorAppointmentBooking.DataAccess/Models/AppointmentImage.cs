﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentBooking.DataAccess.Models
{
    public class AppointmentImage
    {
        public int AppointmentId { get; set; }
        public string PatientEmail { get; set; }
        public string DoctorName { get; set; }
        public string Day { get; set; }
        public IFormFile MedicalReports { get; set; }
        public string AppointmentMode { get; set; }
        public TimeSpan? Time { get; set; }
    }
}

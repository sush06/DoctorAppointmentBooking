﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#nullable disable

namespace DoctorAppointmentBooking.DataAccess.Models
{
    public class DocImage
    {
        public string DoctorId { get; set; }
        public string DoctorEmail { get; set; }
        public string DoctorPassword { get; set; }
        public string DoctorName { get; set; }
        public string Specialization { get; set; }
        public int Experience { get; set; }
        public IFormFile DoctorImage { get; set; }
        public DateTime? Dob { get; set; }
        public string Hospital { get; set; }
        public string Day { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; }
    }
}

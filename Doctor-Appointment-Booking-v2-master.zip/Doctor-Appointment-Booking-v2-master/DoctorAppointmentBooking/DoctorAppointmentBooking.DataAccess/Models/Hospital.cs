﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DoctorAppointmentBooking.DataAccess.Models
{
    public partial class Hospital
    {
        public int HospitalId { get; set; }
        public string HospitalName { get; set; }
    }
}

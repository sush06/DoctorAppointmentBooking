﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentBooking.DataAccess.Models
{
    public class DocLogin
    {
        public string DoctorEmail { get; set; }
        public string DoctorPassword { get; set; }
    }
}

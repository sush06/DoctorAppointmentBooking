﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DoctorAppointmentBooking.DataAccess.Models
{
    public partial class Patient
    {
        public int PatientId { get; set; }
        public string PatientEmail { get; set; }
        public string PatientPassword { get; set; }
        public string PatientName { get; set; }
        public DateTime Dob { get; set; }
        public string Disease { get; set; }
        public byte[] PatientImage { get; set; }
    }
}

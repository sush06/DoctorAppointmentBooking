﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DoctorAppointmentBooking.DataAccess.Models
{
    public partial class Doctor
    {
        public int DoctorId { get; set; }
        public string DoctorEmail { get; set; }
        public string DoctorPassword { get; set; }
        public string DoctorName { get; set; }
        public string Specialization { get; set; }
        public int Experience { get; set; }
        public byte[] DoctorImage { get; set; }
        public DateTime? Dob { get; set; }
        public string Hospital { get; set; }
        public string Day { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; }
    }

    public class APIResponse
    {
        public string Status { get; set; }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentBooking.DataAccess.Models
{
    public class HomeDashboard
    {
        public int DoctorCount { get; set; }
        public int AppointmentCount { get; set; }
        public int PatientCount { get; set; }
    }

    public class Count
    {
        public Count(string name, int count)
        {
            this.doctorName = name;
            this.Counts = count;
        }

        public string doctorName { get; set; }
        public int Counts { get; set; }
    }
}
